# 🐱 Tusa Gato's 24/7 - CRM Prototype

A working prototype for the Tusa Gato's 24/7 Legal Referral Network CRM with AI Receptionist integration.

---

## 🚀 Quick Start

### Prerequisites

- Python 3.11+
- Node.js 18+
- Convex account (free)

### 1. Clone and Setup

```bash
cd tusagatos-crm

# Copy environment file
cp .env.example .env.local
```

### 2. Setup Convex (Database)

```bash
# Install Convex CLI
npm install -g convex

# Login to Convex
npx convex login

# Initialize Convex (creates a new project)
npx convex dev

# This will give you a deployment URL like:
# https://wonderful-fox-123.convex.cloud
# Add this to your .env.local:
# CONVEX_URL=https://wonderful-fox-123.convex.cloud
```

### 3. Start Backend

```bash
cd backend

# Create virtual environment
python -m venv venv

# Activate (macOS/Linux)
source venv/bin/activate

# Activate (Windows)
# venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Start the server
python main.py
```

Backend will be available at `http://localhost:8000`

### 4. Start Frontend

```bash
cd frontend

# Install dependencies
npm install

# Start development server
npm run dev
```

Frontend will be available at `http://localhost:3000`

---

## 🏗️ Architecture

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   RetellAI  │────▶│   Backend   │────▶│   Convex    │
│  (Phone AI) │     │  (FastAPI)  │     │(Database)   │
└─────────────┘     └──────┬──────┘     └─────────────┘
                           │
                    ┌──────┴──────┐
                    │   Frontend  │
                    │  (Next.js)  │
                    └─────────────┘
```

---

## 📁 Project Structure

```
tusagatos-crm/
├── .env                      # Environment variables
├── README.md
├── AGENTS.md                 # Business context
├── ARCHITECTURE.md           # Architecture docs
├── DATA_MODEL.md             # Database schema
├── API_SPEC.md               # API specifications
├── WORKFLOWS.md              # Business logic
│
├── backend/                  # FastAPI Backend
│   ├── main.py              # Main API server
│   └── requirements.txt     # Python dependencies
│
├── frontend/                # Next.js Frontend
│   ├── src/
│   │   ├── app/            # Next.js App Router
│   │   │   ├── page.tsx    # Dashboard
│   │   │   ├── layout.tsx
│   │   │   ├── globals.css
│   │   │   └── api/        # API proxy routes
│   │   └── components/     # React components
│   ├── package.json
│   ├── next.config.js
│   └── tailwind.config.js
│
└── convex/                  # Convex Database
    ├── schema.ts           # Database schema
    ├── leads.ts            # Lead mutations/queries
    └── attorneys.ts        # Attorney mutations/queries
```

---

## 🔧 Environment Variables

Copy `.env.example` to `.env.local` and update:

| Variable | Description |
|----------|-------------|
| `RETELL_API_KEY` | Your RetellAI API key |
| `OPENROUTER_API_KEY` | OpenRouter API key for LLM |
| `CONVEX_URL` | Your Convex deployment URL |
| `SECRET_KEY` | JWT secret (generate new for prod) |

---

## 🎯 Features (MVP)

### ✅ Implemented

1. **AI Receptionist Integration**
   - RetellAI webhook endpoint
   - Automatic lead creation from calls
   - Call transcript storage

2. **Lead Management**
   - Lead creation (AI and manual)
   - Lead listing with filters
   - Lead detail view
   - Qualification scoring

3. **Attorney Matching**
   - Automatic matching by case type + county
   - Match scoring algorithm
   - Lead distribution to attorneys

4. **Dashboard**
   - Real-time lead stats
   - Case type distribution
   - Recent leads table
   - Quick actions

5. **Database (Convex)**
   - Leads, Attorneys, Transfers
   - Real-time subscriptions
   - Scalable serverless backend

---

## 🌐 API Endpoints

### Leads
- `GET /api/leads` - List leads
- `GET /api/leads/:id` - Get lead details
- `POST /api/leads` - Create lead
- `POST /api/leads/:id/notes` - Add note
- `POST /api/leads/:id/convert` - Convert lead

### Attorneys
- `GET /api/attorneys` - List attorneys
- `GET /api/attorneys/:id` - Get attorney
- `POST /api/attorneys` - Create attorney
- `PATCH /api/attorneys/:id` - Update attorney

### Transfers
- `POST /transfers/:id/respond` - Accept/Decline

### Webhooks
- `POST /webhooks/retell` - RetellAI events

### Analytics
- `GET /analytics/dashboard` - Dashboard stats

---

## 🔄 Lead Flow

```
1. INCOMING CALL (24/7)
        ↓
2. RETELLAI ANSWERS
   - Collects: name, phone, case type, county
        ↓
3. WEBHOOK TO CRM
   - Creates lead with qualification score
        ↓
4. MATCHING ENGINE
   - Finds attorneys by case type + county
        ↓
5. ATTORNEY NOTIFICATION
   - Email + SMS sent to top match
        ↓
6. ATTORNEY RESPONSE
   - Accept → Lead converted
   - Decline → Retry with next match
```

---

## 🚀 Deployment

### Backend to Vercel (Serverless)

1. Create `vercel.json`:
```json
{
  "builds": [
    {
      "src": "backend/main.py",
      "use": "@vercel/python"
    }
  ],
  "routes": [
    {
      "src": "/(.*)",
      "dest": "backend/main.py"
    }
  ]
}
```

2. Deploy:
```bash
vercel --prod
```

### Frontend to Vercel

```bash
cd frontend
vercel --prod
```

### Convex

Already deployed! Just run:
```bash
npx convex deploy
```

---

## 📞 Testing the AI Receptionist

### 1. Create Agent in RetellAI

```bash
curl -X POST http://localhost:8000/retell/create-agent
```

Or use the dashboard at `https://beta.retellai.com/dashboard`

### 2. Configure Phone Number

- Buy a number in RetellAI dashboard
- Connect to your agent
- Set webhook URL: `https://your-api.com/webhooks/retell`

### 3. Test Call

Call the number and interact with the AI!

---

## 🛠️ Development

### Backend Development
```bash
cd backend
python main.py
# Auto-reload on code changes
```

### Frontend Development
```bash
cd frontend
npm run dev
# Hot reload on code changes
```

### Convex Development
```bash
npx convex dev
# Watches for schema changes and auto-deploys
```

---

## 📊 Next Steps

1. **Add Authentication** (Clerk/Auth0)
2. **Real-time Notifications** (Twilio/SendGrid)
3. **Attorney Portal** (separate login area)
4. **Call Center Interface** (agent coaching UI)
5. **Advanced Analytics** (charts, reports)
6. **Document Upload** (case files)

---

## 🆘 Troubleshooting

### Backend won't start
```bash
# Check Python version
python --version  # Should be 3.11+

# Check environment variables
grep -E '^(RETELL_API_KEY|OPENROUTER_API_KEY|CONVEX_URL|SECRET_KEY)=' .env.local | sed 's/=.*/=<set>/'
```

### Frontend can't connect to backend
```bash
# Check CORS settings in backend/main.py
# Ensure NEXT_PUBLIC_API_URL is set correctly
```

### Convex errors
```bash
# Re-deploy schema
npx convex dev

# Check deployment URL
npx convex status
```

---

## 📞 Support

For issues or questions, refer to:
- `AGENTS.md` - Business context
- `ARCHITECTURE.md` - System design
- `API_SPEC.md` - API documentation

---

*Built with ❤️ for Tusa Gato's 24/7*
